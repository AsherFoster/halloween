echo Running await
sh await.sh &
